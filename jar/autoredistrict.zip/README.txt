You should be able to just double-click on the file for your OS and it'll run.
It might ask you to extract if you're browsing inside the zip.
Just say yes and then double-click on the extracted version.
If it says something like no privileges, then you have to make the file executable.
To do this, open up a terminal and type "chmod +x [filename]".

Enjoy!
