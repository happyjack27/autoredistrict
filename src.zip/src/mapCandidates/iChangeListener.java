package mapCandidates;

public interface iChangeListener {
	public void valueChanged();
}
